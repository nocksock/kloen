const v = () => {
  const u = /* @__PURE__ */ new Map(), s = (r, t) => (!u.has(r) && u.set(r, /* @__PURE__ */ new Set()), u.get(r).add(t), () => u.get(r).delete(t)), b = (r, t) => {
    var c;
    return (c = u.get(r)) == null || c.forEach((i) => i(t)), t;
  };
  return [s, b, (r, t) => ((c = (i) => (r !== void 0 && i(r), s(c, i))) => {
    c.cur = r;
    const i = (e, g = c) => {
      const n = (o) => (o(n.cur), s(n, o));
      return n.cur = e(g.cur), s(g, (o) => (n.cur = e(o), b(n, n.cur))), [n, (o) => i(o, n)];
    };
    return [
      c,
      t ? (e) => (c.cur = r = t(e, r), b(c, e)) : (e) => (c.cur = e, b(c, e)),
      i
    ];
  })(), u.clear.bind(u)];
}, [w, M, d, x] = v();
export {
  x as clear,
  v as create,
  M as emit,
  w as on,
  d as value
};
